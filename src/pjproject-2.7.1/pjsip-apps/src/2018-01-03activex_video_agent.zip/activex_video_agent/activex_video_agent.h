

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0500 */
/* at Wed Dec 27 17:58:09 2017
 */
/* Compiler settings for ..\src\activex_video_agent\activex_video_agent.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __activex_video_agent_h__
#define __activex_video_agent_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IComponentRegistrar_FWD_DEFINED__
#define __IComponentRegistrar_FWD_DEFINED__
typedef interface IComponentRegistrar IComponentRegistrar;
#endif 	/* __IComponentRegistrar_FWD_DEFINED__ */


#ifndef __IApp_FWD_DEFINED__
#define __IApp_FWD_DEFINED__
typedef interface IApp IApp;
#endif 	/* __IApp_FWD_DEFINED__ */


#ifndef ___IVideoAgentEvents_FWD_DEFINED__
#define ___IVideoAgentEvents_FWD_DEFINED__
typedef interface _IVideoAgentEvents _IVideoAgentEvents;
#endif 	/* ___IVideoAgentEvents_FWD_DEFINED__ */


#ifndef __CompReg_FWD_DEFINED__
#define __CompReg_FWD_DEFINED__

#ifdef __cplusplus
typedef class CompReg CompReg;
#else
typedef struct CompReg CompReg;
#endif /* __cplusplus */

#endif 	/* __CompReg_FWD_DEFINED__ */


#ifndef __App_FWD_DEFINED__
#define __App_FWD_DEFINED__

#ifdef __cplusplus
typedef class App App;
#else
typedef struct App App;
#endif /* __cplusplus */

#endif 	/* __App_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "pjsua-structs.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IComponentRegistrar_INTERFACE_DEFINED__
#define __IComponentRegistrar_INTERFACE_DEFINED__

/* interface IComponentRegistrar */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IComponentRegistrar;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("158FE57D-A272-4978-B836-6392F703FEBF")
    IComponentRegistrar : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Attach( 
            /* [in] */ BSTR bstrPath) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE RegisterAll( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE UnregisterAll( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetComponents( 
            /* [out] */ SAFEARRAY * *pbstrCLSIDs,
            /* [out] */ SAFEARRAY * *pbstrDescriptions) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE RegisterComponent( 
            /* [in] */ BSTR bstrCLSID) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE UnregisterComponent( 
            /* [in] */ BSTR bstrCLSID) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IComponentRegistrarVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IComponentRegistrar * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IComponentRegistrar * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IComponentRegistrar * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IComponentRegistrar * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IComponentRegistrar * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IComponentRegistrar * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IComponentRegistrar * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *Attach )( 
            IComponentRegistrar * This,
            /* [in] */ BSTR bstrPath);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *RegisterAll )( 
            IComponentRegistrar * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *UnregisterAll )( 
            IComponentRegistrar * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *GetComponents )( 
            IComponentRegistrar * This,
            /* [out] */ SAFEARRAY * *pbstrCLSIDs,
            /* [out] */ SAFEARRAY * *pbstrDescriptions);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *RegisterComponent )( 
            IComponentRegistrar * This,
            /* [in] */ BSTR bstrCLSID);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *UnregisterComponent )( 
            IComponentRegistrar * This,
            /* [in] */ BSTR bstrCLSID);
        
        END_INTERFACE
    } IComponentRegistrarVtbl;

    interface IComponentRegistrar
    {
        CONST_VTBL struct IComponentRegistrarVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IComponentRegistrar_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IComponentRegistrar_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IComponentRegistrar_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IComponentRegistrar_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IComponentRegistrar_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IComponentRegistrar_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IComponentRegistrar_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IComponentRegistrar_Attach(This,bstrPath)	\
    ( (This)->lpVtbl -> Attach(This,bstrPath) ) 

#define IComponentRegistrar_RegisterAll(This)	\
    ( (This)->lpVtbl -> RegisterAll(This) ) 

#define IComponentRegistrar_UnregisterAll(This)	\
    ( (This)->lpVtbl -> UnregisterAll(This) ) 

#define IComponentRegistrar_GetComponents(This,pbstrCLSIDs,pbstrDescriptions)	\
    ( (This)->lpVtbl -> GetComponents(This,pbstrCLSIDs,pbstrDescriptions) ) 

#define IComponentRegistrar_RegisterComponent(This,bstrCLSID)	\
    ( (This)->lpVtbl -> RegisterComponent(This,bstrCLSID) ) 

#define IComponentRegistrar_UnregisterComponent(This,bstrCLSID)	\
    ( (This)->lpVtbl -> UnregisterComponent(This,bstrCLSID) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IComponentRegistrar_INTERFACE_DEFINED__ */


#ifndef __IApp_INTERFACE_DEFINED__
#define __IApp_INTERFACE_DEFINED__

/* interface IApp */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IApp;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("93462247-DA4E-4602-817B-26BA0C824E23")
    IApp : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_create( 
            /* [retval][out] */ Pj_Status *retStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_default_config( 
            /* [out] */ VideoAgent_Config *pConfig) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_test_config( 
            /* [in] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ BSTR *errmsg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_init( 
            /* [in] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ Pj_Status *pStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_start( 
            /* [retval][out] */ Pj_Status *retStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_destroy( 
            /* [retval][out] */ Pj_Status *retStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_get_max_count( 
            /* [retval][out] */ int *retCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_get_count( 
            /* [retval][out] */ int *retCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_is_active( 
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Bool *retVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_has_media( 
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Bool *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_get_info( 
            /* [in] */ int call_index,
            /* [out] */ VideoAgent_Call_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_make_call( 
            /* [in] */ int acc_id,
            /* [string][in] */ Pj_String dst_uri,
            /* [out] */ int *call_index,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_answer( 
            /* [in] */ int call_index,
            /* [in] */ int status_code,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_hangup( 
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_set_hold( 
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_release_hold( 
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_xfer( 
            /* [in] */ int call_index,
            /* [string][in] */ Pj_String dst_uri,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_dial_dtmf( 
            /* [in] */ int call_index,
            /* [string][in] */ Pj_String digits,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_send_im( 
            /* [in] */ int call_index,
            /* [string][in] */ Pj_String text,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_typing( 
            /* [in] */ int call_index,
            /* [in] */ int is_typing,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_hangup_all( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_get_count( 
            /* [retval][out] */ int *pCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_get_info( 
            /* [in] */ int acc_id,
            /* [out] */ VideoAgent_Acc_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_add( 
            /* [in] */ VideoAgent_Acc_Config *pConfig,
            /* [out] */ int *pAcc_Index,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_set_online_status( 
            /* [in] */ int acc_id,
            /* [in] */ int is_online,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_set_registration( 
            /* [in] */ int acc_id,
            /* [in] */ int reg_active,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE buddy_get_count( 
            /* [retval][out] */ int *pCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE buddy_get_info( 
            /* [in] */ int buddy_index,
            /* [out] */ VideoAgent_Buddy_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE buddy_add( 
            /* [string][in] */ Pj_String uri,
            /* [out] */ int *pBuddy_Index,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE buddy_subscribe_pres( 
            /* [in] */ int buddy_index,
            /* [in] */ int subscribe,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE im_send_text( 
            /* [in] */ int acc_id,
            /* [string][in] */ Pj_String dst_uri,
            /* [string][in] */ Pj_String text,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE im_typing( 
            /* [in] */ int acc_id,
            /* [string][in] */ Pj_URI dst_uri,
            /* [in] */ int is_typing,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE conf_connect( 
            /* [in] */ int src_port,
            /* [in] */ int sink_port,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE conf_disconnect( 
            /* [in] */ int src_port,
            /* [in] */ int sink_port,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE player_create( 
            /* [string][in] */ Pj_String filename,
            /* [out] */ int *pPlayer_Id,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE player_get_conf_port( 
            /* [in] */ int player_id,
            /* [retval][out] */ int *pPort) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE player_set_pos( 
            /* [in] */ int player_id,
            /* [in] */ int sample_pos,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE player_destroy( 
            /* [in] */ int player_id,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE recorder_create( 
            /* [string][in] */ Pj_String filename,
            /* [out] */ int *pRecorder_Id,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE recorder_get_conf_port( 
            /* [in] */ int recorder_id,
            /* [retval][out] */ int *pPort) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE recorder_destroy( 
            /* [in] */ int recorder_id,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_load_config( 
            /* [string][in] */ Pj_String filename,
            /* [out] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_save_config( 
            /* [string][in] */ Pj_String filename,
            /* [in] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_get_current_config( 
            /* [retval][out] */ VideoAgent_Config *pConfig) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_get_error_msg( 
            /* [in] */ Pj_Status status,
            /* [retval][out] */ BSTR *errmsg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_verify_sip_url( 
            /* [string][in] */ Pj_String uri,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE call_get_textstat( 
            /* [in] */ int call_index,
            /* [retval][out] */ BSTR *textstat) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_handle_events( 
            /* [in] */ int msec_timeout,
            /* [retval][out] */ int *pEvCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_parse_uri( 
            /* [in] */ BSTR uriString,
            /* [out] */ Pjsip_Sip_Uri *pSipUri,
            /* [retval][out] */ Pj_Status *pStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_print_uri( 
            /* [in] */ Pjsip_Sip_Uri *pSipURI,
            /* [in] */ Pjsip_Uri_Context context,
            /* [retval][out] */ BSTR *uriText) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE app_compare_uri_string( 
            /* [in] */ Pjsip_Uri_Context context,
            /* [in] */ BSTR uri1,
            /* [in] */ BSTR uri2,
            /* [retval][out] */ Pj_Status *pStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE buddy_del( 
            /* [in] */ int buddy_index,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_del( 
            /* [in] */ int acc_id,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_find_for_outgoing( 
            /* [in] */ BSTR url,
            /* [out] */ BSTR *abc,
            /* [retval][out] */ int *acc_id) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE acc_enum_id( 
            /* [retval][out] */ SAFEARRAY * *accIdArray) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE conf_enum_ports( 
            /* [retval][out] */ SAFEARRAY * *pPortsArray) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE conf_get_port_info( 
            /* [in] */ int port_id,
            /* [out] */ VideoAgent_Conf_Port_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE aboutbox( 
            /* [out] */ BSTR *str) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE focusua_test_sdl( 
            /* [retval][out] */ Pj_Status *retmsg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE focusua_app_test_config( 
            /* [retval][out] */ BSTR *errmsg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE focusua_init( 
            /* [retval][out] */ Pj_Status *retmsg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE focusua_idestroy( 
            /* [retval][out] */ Pj_Status *retmsg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE focusua_acc_add( 
            /* [in] */ int _00accountId,
            /* [in] */ BSTR _01label,
            /* [in] */ BSTR _02server,
            /* [in] */ BSTR _03proxy,
            /* [in] */ BSTR _04username,
            /* [in] */ BSTR _05domain,
            /* [in] */ int _06port,
            /* [in] */ BSTR _07authID,
            /* [in] */ BSTR _08password,
            /* [in] */ int _09rememberPassword,
            /* [in] */ BSTR _10displayName,
            /* [in] */ BSTR _11voicemailNumber,
            /* [in] */ BSTR _12srtp,
            /* [in] */ BSTR _13transport,
            /* [in] */ BSTR _14publicAddr,
            /* [in] */ int _15publish,
            /* [in] */ int _16ice,
            /* [in] */ int _17allowRewrite,
            /* [in] */ int _18disableSessionTimer,
            /* [out] */ int *pAcc_Index,
            /* [retval][out] */ Pj_Status *retStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE focus_call_make_call( 
            /* [in] */ BSTR _21callId,
            /* [in] */ BSTR _22numb,
            /* [in] */ BSTR _23number,
            /* [in] */ BSTR _24numberParameters,
            /* [in] */ BSTR _25name,
            /* [in] */ int hasVideo,
            /* [retval][out] */ Pj_Status *retStatus) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE focus_change_stream( 
            /* [retval][out] */ Pj_Status *retStatus) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAppVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IApp * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IApp * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IApp * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IApp * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IApp * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IApp * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IApp * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_create )( 
            IApp * This,
            /* [retval][out] */ Pj_Status *retStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_default_config )( 
            IApp * This,
            /* [out] */ VideoAgent_Config *pConfig);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_test_config )( 
            IApp * This,
            /* [in] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ BSTR *errmsg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_init )( 
            IApp * This,
            /* [in] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ Pj_Status *pStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_start )( 
            IApp * This,
            /* [retval][out] */ Pj_Status *retStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_destroy )( 
            IApp * This,
            /* [retval][out] */ Pj_Status *retStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_get_max_count )( 
            IApp * This,
            /* [retval][out] */ int *retCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_get_count )( 
            IApp * This,
            /* [retval][out] */ int *retCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_is_active )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Bool *retVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_has_media )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Bool *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_get_info )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [out] */ VideoAgent_Call_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_make_call )( 
            IApp * This,
            /* [in] */ int acc_id,
            /* [string][in] */ Pj_String dst_uri,
            /* [out] */ int *call_index,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_answer )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [in] */ int status_code,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_hangup )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_set_hold )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_release_hold )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_xfer )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [string][in] */ Pj_String dst_uri,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_dial_dtmf )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [string][in] */ Pj_String digits,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_send_im )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [string][in] */ Pj_String text,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_typing )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [in] */ int is_typing,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_hangup_all )( 
            IApp * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_get_count )( 
            IApp * This,
            /* [retval][out] */ int *pCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_get_info )( 
            IApp * This,
            /* [in] */ int acc_id,
            /* [out] */ VideoAgent_Acc_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_add )( 
            IApp * This,
            /* [in] */ VideoAgent_Acc_Config *pConfig,
            /* [out] */ int *pAcc_Index,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_set_online_status )( 
            IApp * This,
            /* [in] */ int acc_id,
            /* [in] */ int is_online,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_set_registration )( 
            IApp * This,
            /* [in] */ int acc_id,
            /* [in] */ int reg_active,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *buddy_get_count )( 
            IApp * This,
            /* [retval][out] */ int *pCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *buddy_get_info )( 
            IApp * This,
            /* [in] */ int buddy_index,
            /* [out] */ VideoAgent_Buddy_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *buddy_add )( 
            IApp * This,
            /* [string][in] */ Pj_String uri,
            /* [out] */ int *pBuddy_Index,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *buddy_subscribe_pres )( 
            IApp * This,
            /* [in] */ int buddy_index,
            /* [in] */ int subscribe,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *im_send_text )( 
            IApp * This,
            /* [in] */ int acc_id,
            /* [string][in] */ Pj_String dst_uri,
            /* [string][in] */ Pj_String text,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *im_typing )( 
            IApp * This,
            /* [in] */ int acc_id,
            /* [string][in] */ Pj_URI dst_uri,
            /* [in] */ int is_typing,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *conf_connect )( 
            IApp * This,
            /* [in] */ int src_port,
            /* [in] */ int sink_port,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *conf_disconnect )( 
            IApp * This,
            /* [in] */ int src_port,
            /* [in] */ int sink_port,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *player_create )( 
            IApp * This,
            /* [string][in] */ Pj_String filename,
            /* [out] */ int *pPlayer_Id,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *player_get_conf_port )( 
            IApp * This,
            /* [in] */ int player_id,
            /* [retval][out] */ int *pPort);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *player_set_pos )( 
            IApp * This,
            /* [in] */ int player_id,
            /* [in] */ int sample_pos,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *player_destroy )( 
            IApp * This,
            /* [in] */ int player_id,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *recorder_create )( 
            IApp * This,
            /* [string][in] */ Pj_String filename,
            /* [out] */ int *pRecorder_Id,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *recorder_get_conf_port )( 
            IApp * This,
            /* [in] */ int recorder_id,
            /* [retval][out] */ int *pPort);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *recorder_destroy )( 
            IApp * This,
            /* [in] */ int recorder_id,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_load_config )( 
            IApp * This,
            /* [string][in] */ Pj_String filename,
            /* [out] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_save_config )( 
            IApp * This,
            /* [string][in] */ Pj_String filename,
            /* [in] */ VideoAgent_Config *pConfig,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_get_current_config )( 
            IApp * This,
            /* [retval][out] */ VideoAgent_Config *pConfig);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_get_error_msg )( 
            IApp * This,
            /* [in] */ Pj_Status status,
            /* [retval][out] */ BSTR *errmsg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_verify_sip_url )( 
            IApp * This,
            /* [string][in] */ Pj_String uri,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *call_get_textstat )( 
            IApp * This,
            /* [in] */ int call_index,
            /* [retval][out] */ BSTR *textstat);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_handle_events )( 
            IApp * This,
            /* [in] */ int msec_timeout,
            /* [retval][out] */ int *pEvCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_parse_uri )( 
            IApp * This,
            /* [in] */ BSTR uriString,
            /* [out] */ Pjsip_Sip_Uri *pSipUri,
            /* [retval][out] */ Pj_Status *pStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_print_uri )( 
            IApp * This,
            /* [in] */ Pjsip_Sip_Uri *pSipURI,
            /* [in] */ Pjsip_Uri_Context context,
            /* [retval][out] */ BSTR *uriText);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *app_compare_uri_string )( 
            IApp * This,
            /* [in] */ Pjsip_Uri_Context context,
            /* [in] */ BSTR uri1,
            /* [in] */ BSTR uri2,
            /* [retval][out] */ Pj_Status *pStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *buddy_del )( 
            IApp * This,
            /* [in] */ int buddy_index,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_del )( 
            IApp * This,
            /* [in] */ int acc_id,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_find_for_outgoing )( 
            IApp * This,
            /* [in] */ BSTR url,
            /* [out] */ BSTR *abc,
            /* [retval][out] */ int *acc_id);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *acc_enum_id )( 
            IApp * This,
            /* [retval][out] */ SAFEARRAY * *accIdArray);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *conf_enum_ports )( 
            IApp * This,
            /* [retval][out] */ SAFEARRAY * *pPortsArray);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *conf_get_port_info )( 
            IApp * This,
            /* [in] */ int port_id,
            /* [out] */ VideoAgent_Conf_Port_Info *pInfo,
            /* [retval][out] */ Pj_Status *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *aboutbox )( 
            IApp * This,
            /* [out] */ BSTR *str);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *focusua_test_sdl )( 
            IApp * This,
            /* [retval][out] */ Pj_Status *retmsg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *focusua_app_test_config )( 
            IApp * This,
            /* [retval][out] */ BSTR *errmsg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *focusua_init )( 
            IApp * This,
            /* [retval][out] */ Pj_Status *retmsg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *focusua_idestroy )( 
            IApp * This,
            /* [retval][out] */ Pj_Status *retmsg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *focusua_acc_add )( 
            IApp * This,
            /* [in] */ int _00accountId,
            /* [in] */ BSTR _01label,
            /* [in] */ BSTR _02server,
            /* [in] */ BSTR _03proxy,
            /* [in] */ BSTR _04username,
            /* [in] */ BSTR _05domain,
            /* [in] */ int _06port,
            /* [in] */ BSTR _07authID,
            /* [in] */ BSTR _08password,
            /* [in] */ int _09rememberPassword,
            /* [in] */ BSTR _10displayName,
            /* [in] */ BSTR _11voicemailNumber,
            /* [in] */ BSTR _12srtp,
            /* [in] */ BSTR _13transport,
            /* [in] */ BSTR _14publicAddr,
            /* [in] */ int _15publish,
            /* [in] */ int _16ice,
            /* [in] */ int _17allowRewrite,
            /* [in] */ int _18disableSessionTimer,
            /* [out] */ int *pAcc_Index,
            /* [retval][out] */ Pj_Status *retStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *focus_call_make_call )( 
            IApp * This,
            /* [in] */ BSTR _21callId,
            /* [in] */ BSTR _22numb,
            /* [in] */ BSTR _23number,
            /* [in] */ BSTR _24numberParameters,
            /* [in] */ BSTR _25name,
            /* [in] */ int hasVideo,
            /* [retval][out] */ Pj_Status *retStatus);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *focus_change_stream )( 
            IApp * This,
            /* [retval][out] */ Pj_Status *retStatus);
        
        END_INTERFACE
    } IAppVtbl;

    interface IApp
    {
        CONST_VTBL struct IAppVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IApp_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IApp_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IApp_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IApp_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IApp_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IApp_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IApp_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IApp_app_create(This,retStatus)	\
    ( (This)->lpVtbl -> app_create(This,retStatus) ) 

#define IApp_app_default_config(This,pConfig)	\
    ( (This)->lpVtbl -> app_default_config(This,pConfig) ) 

#define IApp_app_test_config(This,pConfig,errmsg)	\
    ( (This)->lpVtbl -> app_test_config(This,pConfig,errmsg) ) 

#define IApp_app_init(This,pConfig,pStatus)	\
    ( (This)->lpVtbl -> app_init(This,pConfig,pStatus) ) 

#define IApp_app_start(This,retStatus)	\
    ( (This)->lpVtbl -> app_start(This,retStatus) ) 

#define IApp_app_destroy(This,retStatus)	\
    ( (This)->lpVtbl -> app_destroy(This,retStatus) ) 

#define IApp_call_get_max_count(This,retCount)	\
    ( (This)->lpVtbl -> call_get_max_count(This,retCount) ) 

#define IApp_call_get_count(This,retCount)	\
    ( (This)->lpVtbl -> call_get_count(This,retCount) ) 

#define IApp_call_is_active(This,call_index,retVal)	\
    ( (This)->lpVtbl -> call_is_active(This,call_index,retVal) ) 

#define IApp_call_has_media(This,call_index,pRet)	\
    ( (This)->lpVtbl -> call_has_media(This,call_index,pRet) ) 

#define IApp_call_get_info(This,call_index,pInfo,pRet)	\
    ( (This)->lpVtbl -> call_get_info(This,call_index,pInfo,pRet) ) 

#define IApp_call_make_call(This,acc_id,dst_uri,call_index,pRet)	\
    ( (This)->lpVtbl -> call_make_call(This,acc_id,dst_uri,call_index,pRet) ) 

#define IApp_call_answer(This,call_index,status_code,pRet)	\
    ( (This)->lpVtbl -> call_answer(This,call_index,status_code,pRet) ) 

#define IApp_call_hangup(This,call_index,pRet)	\
    ( (This)->lpVtbl -> call_hangup(This,call_index,pRet) ) 

#define IApp_call_set_hold(This,call_index,pRet)	\
    ( (This)->lpVtbl -> call_set_hold(This,call_index,pRet) ) 

#define IApp_call_release_hold(This,call_index,pRet)	\
    ( (This)->lpVtbl -> call_release_hold(This,call_index,pRet) ) 

#define IApp_call_xfer(This,call_index,dst_uri,pRet)	\
    ( (This)->lpVtbl -> call_xfer(This,call_index,dst_uri,pRet) ) 

#define IApp_call_dial_dtmf(This,call_index,digits,pRet)	\
    ( (This)->lpVtbl -> call_dial_dtmf(This,call_index,digits,pRet) ) 

#define IApp_call_send_im(This,call_index,text,pRet)	\
    ( (This)->lpVtbl -> call_send_im(This,call_index,text,pRet) ) 

#define IApp_call_typing(This,call_index,is_typing,pRet)	\
    ( (This)->lpVtbl -> call_typing(This,call_index,is_typing,pRet) ) 

#define IApp_call_hangup_all(This)	\
    ( (This)->lpVtbl -> call_hangup_all(This) ) 

#define IApp_acc_get_count(This,pCount)	\
    ( (This)->lpVtbl -> acc_get_count(This,pCount) ) 

#define IApp_acc_get_info(This,acc_id,pInfo,pRet)	\
    ( (This)->lpVtbl -> acc_get_info(This,acc_id,pInfo,pRet) ) 

#define IApp_acc_add(This,pConfig,pAcc_Index,pRet)	\
    ( (This)->lpVtbl -> acc_add(This,pConfig,pAcc_Index,pRet) ) 

#define IApp_acc_set_online_status(This,acc_id,is_online,pRet)	\
    ( (This)->lpVtbl -> acc_set_online_status(This,acc_id,is_online,pRet) ) 

#define IApp_acc_set_registration(This,acc_id,reg_active,pRet)	\
    ( (This)->lpVtbl -> acc_set_registration(This,acc_id,reg_active,pRet) ) 

#define IApp_buddy_get_count(This,pCount)	\
    ( (This)->lpVtbl -> buddy_get_count(This,pCount) ) 

#define IApp_buddy_get_info(This,buddy_index,pInfo,pRet)	\
    ( (This)->lpVtbl -> buddy_get_info(This,buddy_index,pInfo,pRet) ) 

#define IApp_buddy_add(This,uri,pBuddy_Index,pRet)	\
    ( (This)->lpVtbl -> buddy_add(This,uri,pBuddy_Index,pRet) ) 

#define IApp_buddy_subscribe_pres(This,buddy_index,subscribe,pRet)	\
    ( (This)->lpVtbl -> buddy_subscribe_pres(This,buddy_index,subscribe,pRet) ) 

#define IApp_im_send_text(This,acc_id,dst_uri,text,pRet)	\
    ( (This)->lpVtbl -> im_send_text(This,acc_id,dst_uri,text,pRet) ) 

#define IApp_im_typing(This,acc_id,dst_uri,is_typing,pRet)	\
    ( (This)->lpVtbl -> im_typing(This,acc_id,dst_uri,is_typing,pRet) ) 

#define IApp_conf_connect(This,src_port,sink_port,pRet)	\
    ( (This)->lpVtbl -> conf_connect(This,src_port,sink_port,pRet) ) 

#define IApp_conf_disconnect(This,src_port,sink_port,pRet)	\
    ( (This)->lpVtbl -> conf_disconnect(This,src_port,sink_port,pRet) ) 

#define IApp_player_create(This,filename,pPlayer_Id,pRet)	\
    ( (This)->lpVtbl -> player_create(This,filename,pPlayer_Id,pRet) ) 

#define IApp_player_get_conf_port(This,player_id,pPort)	\
    ( (This)->lpVtbl -> player_get_conf_port(This,player_id,pPort) ) 

#define IApp_player_set_pos(This,player_id,sample_pos,pRet)	\
    ( (This)->lpVtbl -> player_set_pos(This,player_id,sample_pos,pRet) ) 

#define IApp_player_destroy(This,player_id,pRet)	\
    ( (This)->lpVtbl -> player_destroy(This,player_id,pRet) ) 

#define IApp_recorder_create(This,filename,pRecorder_Id,pRet)	\
    ( (This)->lpVtbl -> recorder_create(This,filename,pRecorder_Id,pRet) ) 

#define IApp_recorder_get_conf_port(This,recorder_id,pPort)	\
    ( (This)->lpVtbl -> recorder_get_conf_port(This,recorder_id,pPort) ) 

#define IApp_recorder_destroy(This,recorder_id,pRet)	\
    ( (This)->lpVtbl -> recorder_destroy(This,recorder_id,pRet) ) 

#define IApp_app_load_config(This,filename,pConfig,pRet)	\
    ( (This)->lpVtbl -> app_load_config(This,filename,pConfig,pRet) ) 

#define IApp_app_save_config(This,filename,pConfig,pRet)	\
    ( (This)->lpVtbl -> app_save_config(This,filename,pConfig,pRet) ) 

#define IApp_app_get_current_config(This,pConfig)	\
    ( (This)->lpVtbl -> app_get_current_config(This,pConfig) ) 

#define IApp_app_get_error_msg(This,status,errmsg)	\
    ( (This)->lpVtbl -> app_get_error_msg(This,status,errmsg) ) 

#define IApp_app_verify_sip_url(This,uri,pRet)	\
    ( (This)->lpVtbl -> app_verify_sip_url(This,uri,pRet) ) 

#define IApp_call_get_textstat(This,call_index,textstat)	\
    ( (This)->lpVtbl -> call_get_textstat(This,call_index,textstat) ) 

#define IApp_app_handle_events(This,msec_timeout,pEvCount)	\
    ( (This)->lpVtbl -> app_handle_events(This,msec_timeout,pEvCount) ) 

#define IApp_app_parse_uri(This,uriString,pSipUri,pStatus)	\
    ( (This)->lpVtbl -> app_parse_uri(This,uriString,pSipUri,pStatus) ) 

#define IApp_app_print_uri(This,pSipURI,context,uriText)	\
    ( (This)->lpVtbl -> app_print_uri(This,pSipURI,context,uriText) ) 

#define IApp_app_compare_uri_string(This,context,uri1,uri2,pStatus)	\
    ( (This)->lpVtbl -> app_compare_uri_string(This,context,uri1,uri2,pStatus) ) 

#define IApp_buddy_del(This,buddy_index,pRet)	\
    ( (This)->lpVtbl -> buddy_del(This,buddy_index,pRet) ) 

#define IApp_acc_del(This,acc_id,pRet)	\
    ( (This)->lpVtbl -> acc_del(This,acc_id,pRet) ) 

#define IApp_acc_find_for_outgoing(This,url,abc,acc_id)	\
    ( (This)->lpVtbl -> acc_find_for_outgoing(This,url,abc,acc_id) ) 

#define IApp_acc_enum_id(This,accIdArray)	\
    ( (This)->lpVtbl -> acc_enum_id(This,accIdArray) ) 

#define IApp_conf_enum_ports(This,pPortsArray)	\
    ( (This)->lpVtbl -> conf_enum_ports(This,pPortsArray) ) 

#define IApp_conf_get_port_info(This,port_id,pInfo,pRet)	\
    ( (This)->lpVtbl -> conf_get_port_info(This,port_id,pInfo,pRet) ) 

#define IApp_aboutbox(This,str)	\
    ( (This)->lpVtbl -> aboutbox(This,str) ) 

#define IApp_focusua_test_sdl(This,retmsg)	\
    ( (This)->lpVtbl -> focusua_test_sdl(This,retmsg) ) 

#define IApp_focusua_app_test_config(This,errmsg)	\
    ( (This)->lpVtbl -> focusua_app_test_config(This,errmsg) ) 

#define IApp_focusua_init(This,retmsg)	\
    ( (This)->lpVtbl -> focusua_init(This,retmsg) ) 

#define IApp_focusua_idestroy(This,retmsg)	\
    ( (This)->lpVtbl -> focusua_idestroy(This,retmsg) ) 

#define IApp_focusua_acc_add(This,_00accountId,_01label,_02server,_03proxy,_04username,_05domain,_06port,_07authID,_08password,_09rememberPassword,_10displayName,_11voicemailNumber,_12srtp,_13transport,_14publicAddr,_15publish,_16ice,_17allowRewrite,_18disableSessionTimer,pAcc_Index,retStatus)	\
    ( (This)->lpVtbl -> focusua_acc_add(This,_00accountId,_01label,_02server,_03proxy,_04username,_05domain,_06port,_07authID,_08password,_09rememberPassword,_10displayName,_11voicemailNumber,_12srtp,_13transport,_14publicAddr,_15publish,_16ice,_17allowRewrite,_18disableSessionTimer,pAcc_Index,retStatus) ) 

#define IApp_focus_call_make_call(This,_21callId,_22numb,_23number,_24numberParameters,_25name,hasVideo,retStatus)	\
    ( (This)->lpVtbl -> focus_call_make_call(This,_21callId,_22numb,_23number,_24numberParameters,_25name,hasVideo,retStatus) ) 

#define IApp_focus_change_stream(This,retStatus)	\
    ( (This)->lpVtbl -> focus_change_stream(This,retStatus) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IApp_INTERFACE_DEFINED__ */



#ifndef __ACTIVEVIDEOAGENTLib_LIBRARY_DEFINED__
#define __ACTIVEVIDEOAGENTLib_LIBRARY_DEFINED__

/* library ACTIVEVIDEOAGENTLib */
/* [custom][helpstring][version][uuid] */ 









EXTERN_C const IID LIBID_ACTIVEVIDEOAGENTLib;

#ifndef ___IVideoAgentEvents_DISPINTERFACE_DEFINED__
#define ___IVideoAgentEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IVideoAgentEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IVideoAgentEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("DC91CBCE-4B9E-4369-80B9-39341EEFD814")
    _IVideoAgentEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IVideoAgentEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _IVideoAgentEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _IVideoAgentEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _IVideoAgentEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _IVideoAgentEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _IVideoAgentEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _IVideoAgentEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _IVideoAgentEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _IVideoAgentEventsVtbl;

    interface _IVideoAgentEvents
    {
        CONST_VTBL struct _IVideoAgentEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IVideoAgentEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define _IVideoAgentEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define _IVideoAgentEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define _IVideoAgentEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define _IVideoAgentEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define _IVideoAgentEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define _IVideoAgentEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IVideoAgentEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_CompReg;

#ifdef __cplusplus

class DECLSPEC_UUID("0728CAC5-2AF1-4607-B810-547628688E43")
CompReg;
#endif

EXTERN_C const CLSID CLSID_App;

#ifdef __cplusplus

class DECLSPEC_UUID("F89DA516-42E5-43A0-8EF7-A960BA386CAB")
App;
#endif
#endif /* __ACTIVEVIDEOAGENTLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long *, unsigned long            , LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long *, unsigned char *, LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long *, unsigned char *, LPSAFEARRAY * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long *, LPSAFEARRAY * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


