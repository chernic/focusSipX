

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 7.00.0500 */
/* at Wed Dec 27 17:58:09 2017
 */
/* Compiler settings for ..\src\activex_video_agent\activex_video_agent.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IComponentRegistrar,0x158FE57D,0xA272,0x4978,0xB8,0x36,0x63,0x92,0xF7,0x03,0xFE,0xBF);


MIDL_DEFINE_GUID(IID, IID_IApp,0x93462247,0xDA4E,0x4602,0x81,0x7B,0x26,0xBA,0x0C,0x82,0x4E,0x23);


MIDL_DEFINE_GUID(IID, LIBID_ACTIVEVIDEOAGENTLib,0x11E70413,0x8434,0x41B6,0xA5,0xB6,0xF7,0xDF,0x79,0xFE,0xFC,0x1A);


MIDL_DEFINE_GUID(IID, DIID__IVideoAgentEvents,0xDC91CBCE,0x4B9E,0x4369,0x80,0xB9,0x39,0x34,0x1E,0xEF,0xD8,0x14);


MIDL_DEFINE_GUID(CLSID, CLSID_CompReg,0x0728CAC5,0x2AF1,0x4607,0xB8,0x10,0x54,0x76,0x28,0x68,0x8E,0x43);


MIDL_DEFINE_GUID(CLSID, CLSID_App,0xF89DA516,0x42E5,0x43A0,0x8E,0xF7,0xA9,0x60,0xBA,0x38,0x6C,0xAB);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



