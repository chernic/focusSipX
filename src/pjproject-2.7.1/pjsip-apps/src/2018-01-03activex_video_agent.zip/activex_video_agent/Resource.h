//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by activex_video_agent.rc
//
#define IDS_PROJNAME                    110
#define IDR_APP                         111
#define IDD_PREVIEW                     112
#define IDD_COMPLEX                     113
#define IDD_HANGUP                      201
#define IDC_HANGUP                      202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
