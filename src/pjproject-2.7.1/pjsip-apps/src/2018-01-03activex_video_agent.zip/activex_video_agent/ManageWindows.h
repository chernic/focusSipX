// ManageWindows.h : Declaration of the CApp

#ifndef __MANAGE_WINDOWS_H_
#define __MANAGE_WINDOWS_H_

#include "define.h"
#include "resource.h"       // main symbols
#include "settings.h"

#ifdef _GLOBAL_VIDEO
void ResetPJmedia(void);
void ResetPJmediaData(void);
void CreateAddPreviewToWindow(PosSize_t psP, void * x);
void AddPreviewToWindow(PosSize_t psP);
void AddStreamToWindow(PosSize_t psS);
int  ShowPreviewWindow(pj_bool_t IsShow);
int  ShowStreamWindow(pj_bool_t IsShow);
int SetPreviewParent(HWND parent);
int SetStreamParent(HWND parent);

#endif

#endif //__MANAGE_WINDOWS_H_



